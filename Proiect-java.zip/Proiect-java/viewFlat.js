const storedViewFlat=JSON.parse(localStorage.getItem("apartament"));
const